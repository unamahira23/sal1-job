#!/bin/bash

# Cek dan bersihkan sesi screen yang lama
echo "Cek dan bersihkan sesi screen yang lama..."
screen -ls
screen -wipe

# Jalankan xmrig di screen baru dengan konfigurasi dan thread yang sesuai
echo "Memulai xmrig di screen 'github'..."
screen -S github -dm ./xmrig --config=config.json --threads=3

# Konfirmasi
echo "Xmrig sudah berjalan di screen 'github'."
